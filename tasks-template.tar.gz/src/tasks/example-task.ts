// @opcbTaskName Example task
// @opcbTaskDescription This task serves for automation module testing.

import { workerData } from "worker_threads";
import { getUserJson, setTestWorkerData } from "@overvis/opcb-tasks-helpers";
import { Type } from "@sinclair/typebox";

setTestWorkerData({ userJson: '{"successChance": 0.95}' });

async function run(): Promise<void> {
    console.log("Running...");
    console.log(`Current time: ${new Date().toISOString()}`);

    console.log("Worker data:");
    console.log(workerData);
    const successChance = getUserJson(Type.Object({ successChance: Type.Number() })).successChance;
    console.log(`Success chance: ${successChance}`);

    await new Promise((_resolve, reject) => {
        setInterval(() => {
            const rnd = Math.random();
            if (rnd > successChance) {
                console.log(`Unsuccessful iteration: ${rnd}`);
                reject(new Error("Some error"));
            } else {
                console.log(`Successful iteration: ${rnd}`);
            }
        }, 1000);
    });
}

run();
