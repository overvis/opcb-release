/* eslint-disable @typescript-eslint/no-unused-vars */
// @opcbTaskName params historian task
// @opcbTaskDescription This task sniffs the bus for the connected devices parameters data, then converts the data into parameters (according to their device type from devices table), and finally stores the data into parameters history table in sqlite DB.

import {
    connectMainDb,
    connectMemDb,
    getCmdBusSubscriber,
    getUserJson,
    setTestWorkerData,
} from "@overvis/opcb-tasks-helpers";
import { redisCmd, SqliteDatabase, SqliteStatement } from "@overvis/opcb-ts-shared";
import { Static, Type } from "@sinclair/typebox";

const CONFIG_SCHEMA = Type.Object({
    logAdvsGeneralData: Type.Optional(Type.Boolean()),
    logAdvsCustomData: Type.Optional(Type.Boolean()),
    lwgCalcItemsFromLogs: Type.Optional(Type.Boolean()),
    lwgCalcItemsFromAdvs: Type.Optional(Type.Boolean()),
    addUnitsToValue: Type.Optional(Type.Boolean()),
});
type Config = Static<typeof CONFIG_SCHEMA>;

setTestWorkerData({
    taskId: "param-historian",
    userJson: JSON.stringify({
        logAdvsGeneralData: true,
    } satisfies Config),
});

interface DeviceParameterType {
    kind: "real" | "integer" | "boolean";
    minimum?: number;
    maximum?: number;
    multiplier?: number;
}

interface DeviceParameterValueDescriptor {
    unit?: string;
    fractionDigits?: number;
    type: DeviceParameterType;
    variants?: Record<number, string>;
    errors?: {
        check?: { flagMask: number; flagValue: number; keyMask: number; default: string };
        variants: Record<number, string>;
    };
    mapper:
        | "u8"
        | "i8"
        | "u16-be"
        | "u16-le"
        | "i16-be"
        | "i16-le"
        | "u32-be"
        | "u32-le"
        | "i32-be"
        | "i32-le"
        | "float-be"
        | "float-le";
}

interface DeviceParameterLogPosition {
    checks: {
        address: number;
        flagMask: number;
        flagValue: number;
    }[];
    address: number;
}

interface DeviceParameter {
    lsMap: DeviceParameterValueDescriptor;
    lsLogMap?: DeviceParameterValueDescriptor;
    lsAdvAddress?: number;
    lsAdvMeasuredOnAddress?: number;
    lsLogPosition?: DeviceParameterLogPosition;
}

interface DeviceParameterResult {
    timestamp: Date;
    value?: string;
    error?: string;
}

function deviceParametersList(
    deviceSku: string,
    firmwareVersion?: number,
): Record<string, DeviceParameter> {
    const params: Record<string, DeviceParameter> = {};
    switch (deviceSku) {
        case "lth-1": {
            // const errors = {
            //     0x8000: "SENSOR_NO_ERROR",
            //     0x8001: "SENSOR_ERR_NO_CALIBR",
            //     0x8002: "SENSOR_ERR_DATA_OVERFLOW",
            //     0x8003: "SENSOR_ERR_NOT_FOUND",
            // };
            params["temperature_degree"] = {
                lsMap: {
                    unit: "\u0176C",
                    fractionDigits: 2,
                    type: {
                        kind: "real",
                        minimum: -250.0,
                        maximum: +250.0,
                        multiplier: 0.01,
                    },
                    mapper: "i16-be",
                },
                lsAdvAddress: 0,
            };
            params["humidity_percent"] = {
                lsMap: {
                    unit: "%",
                    fractionDigits: 1,
                    type: {
                        kind: "real",
                        minimum: 0.0,
                        maximum: 100.0,
                        multiplier: 0.1,
                    },
                    mapper: "i16-be",
                },
                lsAdvAddress: 2,
            };
            break;
        }
        case "lwg-1": {
            const errors = {
                "1": "SENSOR_ERR_DISABLED",
                "2": "SENSOR_ERR_NO_CALIBR",
                "3": "SENSOR_ERR_IO_TIMEOUT",
                "4": "SENSOR_ERR_DATA_OVERFLOW",
                "5": "SENSOR_ERR_NOT_FOUND",
            };
            const lsAdvMap: DeviceParameterValueDescriptor = {
                unit: "g",
                fractionDigits: 0,
                type: {
                    kind: "integer",
                    minimum: -100000000,
                    maximum: +100000000,
                    multiplier: 1,
                },
                errors: {
                    check: {
                        flagMask: 0xff000000,
                        flagValue: -0x80000000,
                        keyMask: 0xffff,
                        default: "SENSOR_ERR_UNKNOWN",
                    },
                    variants: errors,
                },
                mapper: "i32-be",
            };
            const lsLogMap = structuredClone(lsAdvMap);
            if (firmwareVersion && firmwareVersion < 3) {
                lsLogMap.mapper = "i32-le";
            }
            for (let i = 0; i < 8; i += 1) {
                params[`weight_${i + 1}_g`] = {
                    lsMap: lsAdvMap,
                    lsLogMap,
                    lsAdvAddress: (i + 1) * 4,
                    lsAdvMeasuredOnAddress: 0,
                    lsLogPosition: {
                        checks: [
                            {
                                address: 0,
                                flagMask: 0x07,
                                flagValue: i,
                            },
                        ],
                        address: 1,
                    },
                };
            }
            break;
        }
        default:
            throw Error(`Unknown device SKU ${deviceSku}`);
    }

    return params;
}

function extractParameterValue(
    buffer: Buffer,
    map: DeviceParameterValueDescriptor,
    valueAddress: number,
    receivedOn: Date,
    valueUnits: boolean,
    receivedClock?: number,
    measuredClockAddress?: number,
): DeviceParameterResult {
    /* map buffer data into number */
    let mappedData: number;
    switch (map.mapper) {
        case "u8":
            mappedData = buffer.readUInt8(valueAddress);
            break;
        case "i8":
            mappedData = buffer.readInt8(valueAddress);
            break;
        case "u16-be":
            mappedData = buffer.readUInt16BE(valueAddress);
            break;
        case "u16-le":
            mappedData = buffer.readUInt16LE(valueAddress);
            break;
        case "i16-be":
            mappedData = buffer.readInt16BE(valueAddress);
            break;
        case "i16-le":
            mappedData = buffer.readInt16LE(valueAddress);
            break;
        case "u32-be":
            mappedData = buffer.readUInt32BE(valueAddress);
            break;
        case "i32-be":
            mappedData = buffer.readInt32BE(valueAddress);
            break;
        case "u32-le":
            mappedData = buffer.readUInt32LE(valueAddress);
            break;
        case "i32-le":
            mappedData = buffer.readInt32LE(valueAddress);
            break;
        case "float-be":
            mappedData = buffer.readFloatBE(valueAddress);
            break;
        case "float-le":
            mappedData = buffer.readFloatLE(valueAddress);
            break;
        default:
            throw Error(`Parameter mapper unknown: ${map.mapper}`);
    }

    /* map timestamp */
    const paramResult: DeviceParameterResult = { timestamp: new Date(receivedOn.valueOf()) };
    if (receivedClock !== undefined && measuredClockAddress !== undefined) {
        paramResult.timestamp.setTime(
            paramResult.timestamp.getTime() -
                receivedClock * 1000 +
                buffer.readInt32BE(measuredClockAddress) * 1000,
        );
    }

    if (map.variants) {
        throw Error(`Parameter variants unimplemented`);
    }

    /* map errors, if any */
    if (map.errors?.check) {
        if ((mappedData & map.errors.check.flagMask) === map.errors.check.flagValue) {
            const errVariant = map.errors.variants[mappedData & map.errors.check.keyMask];
            paramResult.error = errVariant ? errVariant : map.errors.check.default;
        }
    } else if (map.errors?.variants[mappedData]) {
        paramResult.error = map.errors.variants[mappedData];
    }

    if (paramResult.value || paramResult.error) {
        return paramResult;
    }

    /* map value */
    switch (map.type.kind) {
        case "boolean":
            paramResult.value = mappedData === 0 ? "false" : "true";
            break;
        case "integer": {
            let reducedValue = map.type.multiplier
                ? Math.round(mappedData * map.type.multiplier)
                : mappedData;

            if (map.type.minimum && mappedData < map.type.minimum) {
                console.log(
                    `Parameter value ${mappedData} < minimum ${map.type.minimum} (saturated)`,
                );
                reducedValue = map.type.minimum;
            } else if (map.type.maximum && mappedData > map.type.maximum) {
                console.log(
                    `Parameter value ${mappedData} > maximum ${map.type.maximum} (saturated)`,
                );
                reducedValue = map.type.maximum;
            }
            paramResult.value = reducedValue.toString() + (valueUnits ? map.unit : "");

            break;
        }
        case "real": {
            let reducedValue = map.type.multiplier ? mappedData * map.type.multiplier : mappedData;

            if (map.type.minimum && reducedValue < map.type.minimum) {
                console.log(
                    `Parameter value ${reducedValue} < minimum ${map.type.minimum} (saturated)`,
                );
                reducedValue = map.type.minimum;
            } else if (map.type.maximum && reducedValue > map.type.maximum) {
                console.log(
                    `Parameter value ${reducedValue} > maximum ${map.type.maximum} (saturated)`,
                );
                reducedValue = map.type.maximum;
            }
            paramResult.value =
                (map.fractionDigits
                    ? reducedValue.toLocaleString("en-US", {
                          maximumFractionDigits: map.fractionDigits,
                          minimumFractionDigits: map.fractionDigits,
                      })
                    : reducedValue.toString()) + (valueUnits ? map.unit : "");

            break;
        }
        default:
            throw Error(`Unknown type ${map.type.kind}`);
    }

    return paramResult;
}

function lwgShelfNumber(paramId: string): number | undefined {
    switch (paramId) {
        case "weight_1_g":
            return 1;
        case "weight_2_g":
            return 2;
        case "weight_3_g":
            return 3;
        case "weight_4_g":
            return 4;
        case "weight_5_g":
            return 5;
        case "weight_6_g":
            return 6;
        case "weight_7_g":
            return 7;
        case "weight_8_g":
            return 8;
        default:
            return undefined;
    }
}

function lwgWeightToItems(
    weightBrutto: number,
    itemWeight: number,
    fixedTareWeight?: number,
    stackedTareWeight?: number,
    stackedTareItemsMax?: number,
): number {
    let weightNettoG = weightBrutto;

    /* if fixed tare weight specified - subtract it */
    if (fixedTareWeight) weightNettoG -= fixedTareWeight;

    let itemsCount = 0;

    /* if stacked tare weight and capacity specified */
    if (stackedTareWeight && stackedTareItemsMax) {
        const fullTareWeight = stackedTareWeight + itemWeight * stackedTareItemsMax;

        /* subtract all the full tare */
        while (weightNettoG > fullTareWeight) {
            itemsCount += stackedTareItemsMax;
            weightNettoG -= fullTareWeight;
        }

        /* subtract the last half-empty tare */
        weightNettoG -= stackedTareWeight;
    }

    if (weightNettoG > 0) {
        itemsCount += Math.round(weightNettoG / itemWeight);
    }

    return itemsCount;
}

function calcLwgWeightParamDerivatives(
    deviceId: string,
    shelfNumber: number,
    weightReading: DeviceParameterResult,
    calculateLoaded: boolean,
    queries: Pick<Queries, "selectParamLastValue" | "selectShelfConfig">,
): { itemsCount: number; loaded?: number; unloaded?: number } | undefined {
    if (weightReading.value === undefined) {
        return;
    }
    const weightBrutto = parseInt(weightReading.value);
    if (isNaN(weightBrutto)) {
        return;
    }

    const shelfConfig = queries.selectShelfConfig(deviceId, `weight_${shelfNumber}_g`);
    if (!shelfConfig) {
        return;
    }

    const itemsCount = lwgWeightToItems(
        weightBrutto,
        shelfConfig.item_weight_g,
        shelfConfig.fixed_tare_weight_g,
        shelfConfig.stacked_tare_weight_g,
        shelfConfig.stacked_tare_items_max,
    );
    const result: ReturnType<typeof calcLwgWeightParamDerivatives> = { itemsCount };

    if (!calculateLoaded) {
        return result;
    }

    const itemsParamId = `items_${shelfNumber}`;
    const lastItemsCount =
        queries.selectParamLastValue(
            deviceId,
            itemsParamId,
            weightReading.timestamp.getTime() / 1000,
        ) || 0;

    const itemsChange = itemsCount - lastItemsCount;

    if (itemsChange > 0) {
        let loaded = +(
            queries.selectParamLastValue(
                deviceId,
                `loaded_${shelfNumber}`,
                weightReading.timestamp.getTime() / 1000,
            ) || 0
        );
        loaded += itemsChange;
        result.loaded = loaded;
    } else if (itemsChange < 0) {
        let unloaded = +(
            queries.selectParamLastValue(
                deviceId,
                `unloaded_${shelfNumber}`,
                weightReading.timestamp.getTime() / 1000,
            ) || 0
        );
        unloaded += Math.abs(itemsChange);
        result.unloaded = unloaded;
    }

    return result;
}

function processLwgParamValue(
    sku: string,
    deviceId: string,
    paramId: string,
    paramValue: DeviceParameterResult,
    queries: Pick<Queries, "selectParamLastValue" | "selectShelfConfig">,
    lastParamRecords?: Record<string, DeviceParameterResult>,
    logParamRecords?: Record<string, DeviceParameterResult>,
): void {
    if (
        paramValue.error !== undefined ||
        paramValue.value === undefined ||
        sku.substring(0, 3) !== "lwg"
    ) {
        return;
    }

    const shelfNumber = lwgShelfNumber(paramId);
    if (!shelfNumber) {
        return;
    }

    const itemParams = calcLwgWeightParamDerivatives(
        deviceId,
        shelfNumber,
        paramValue,
        !!logParamRecords,
        queries,
    );
    if (!itemParams) {
        return;
    }

    const items = {
        timestamp: paramValue.timestamp,
        value: itemParams.itemsCount.toString(),
    };
    const loaded = {
        timestamp: paramValue.timestamp,
        value: itemParams.loaded?.toString(),
    };
    const unloaded = {
        timestamp: paramValue.timestamp,
        value: itemParams.unloaded?.toString(),
    };
    if (lastParamRecords) {
        lastParamRecords[`items_${shelfNumber}`] = items;
        lastParamRecords[`loaded_${shelfNumber}`] = loaded;
        lastParamRecords[`unloaded_${shelfNumber}`] = unloaded;
    }
    if (logParamRecords) {
        logParamRecords[`items_${shelfNumber}`] = items;
        logParamRecords[`loaded_${shelfNumber}`] = loaded;
        logParamRecords[`unloaded_${shelfNumber}`] = unloaded;
    }
}

function createLsAdvHandler(
    config: {
        addUnitsToValue: boolean;
        logGeneralData: boolean;
        logCustomData: boolean;
        lwgCalcItemsFromAdvs: boolean;
    },
    queries: Queries,
): (cmd: redisCmd.LoraSensAdvertise) => Promise<void> {
    return async (cmd) => {
        const device = queries.selectLorasensDevice(cmd.did);

        if (!device || device.device_id === undefined || device.sku === undefined) {
            console.log(`Unknown device ${cmd.did}`);
            return;
        }

        /* get parameters template according to device SKU */
        const params = deviceParametersList(
            device.sku,
            device.firmware_version === null ? undefined : device.firmware_version,
        );

        /* iterate params objects to extract the data and prepare for the insertion */
        let logParamRecords: Record<string, DeviceParameterResult> = {};
        const lastParamRecords: Record<string, DeviceParameterResult> = {};
        for (const paramId in params) {
            const param = params[paramId];
            if (!param.lsAdvAddress) {
                continue;
            }
            const paramValue = extractParameterValue(
                cmd.data,
                param.lsMap,
                param.lsAdvAddress,
                cmd.packetReceivedOn,
                config.addUnitsToValue,
                cmd.secondsSincePowerUp,
                param.lsAdvMeasuredOnAddress,
            );
            lastParamRecords[paramId] = paramValue;
            logParamRecords[paramId] = lastParamRecords[paramId];

            /* saving items counts for LWG SKU */
            processLwgParamValue(
                device.sku,
                device.device_id,
                paramId,
                paramValue,
                queries,
                lastParamRecords,
                config.lwgCalcItemsFromAdvs ? logParamRecords : undefined,
            );
        }

        queries.upsertLastReadings(device.device_id, lastParamRecords);

        const { logGeneralData, logCustomData, addUnitsToValue } = config;
        if (!logGeneralData && !logCustomData) {
            return;
        }

        /* insert new log values into sqlite table */

        if (!logCustomData) {
            logParamRecords = {};
        }

        if (logGeneralData) {
            logParamRecords["batteryPercents"] = {
                timestamp: cmd.packetReceivedOn,
                value: cmd.batteryPercentage.toString() + (addUnitsToValue ? "%" : ""),
            };
            logParamRecords["timeSinceResetSeconds"] = {
                timestamp: cmd.packetReceivedOn,
                value: cmd.secondsSincePowerUp.toString() + (addUnitsToValue ? "s" : ""),
            };
            logParamRecords["rxSignalDbm"] = {
                timestamp: cmd.packetReceivedOn,
                value: cmd.signalDbm.toString() + (addUnitsToValue ? "dBm" : ""),
            };
        }

        queries.insertLogRecords(device.device_id, logParamRecords);
    };
}

function createLsLogHandler(
    valueUnits: boolean,
    lwgCalcItemsFromLogs: boolean,
    queries: Queries,
): (cmd: redisCmd.LoraSensLog) => Promise<void> {
    return async (cmd) => {
        const device = queries.selectLorasensDevice(cmd.did);

        if (!device || device.device_id === undefined || device.sku === undefined) {
            console.log(`Unknown device ${cmd.did}`);
            return;
        }

        /* get parameters template according to device SKU */
        const params = deviceParametersList(
            device.sku,
            device.firmware_version === null ? undefined : device.firmware_version,
        );

        /* iterate params objects to extract the data and prepare for the insertion */
        for (const record of cmd.records) {
            const logParamRecords: Record<string, DeviceParameterResult> = {};

            for (const paramId in params) {
                const param = params[paramId];
                if (!param.lsLogPosition) {
                    continue;
                }

                let match = true;
                for (const c of param.lsLogPosition.checks) {
                    match =
                        match &&
                        c.address >= 0 &&
                        c.address < record.data.length &&
                        (record.data.readUInt8(c.address) & c.flagMask) == c.flagValue;
                }

                if (!match) {
                    continue;
                }

                const paramValue = extractParameterValue(
                    record.data,
                    param.lsLogMap ? param.lsLogMap : param.lsMap,
                    param.lsLogPosition.address,
                    record.timestamp,
                    valueUnits,
                );
                logParamRecords[paramId] = paramValue;

                /* saving items counts for LWG SKU */
                if (!lwgCalcItemsFromLogs) {
                    continue;
                }
                processLwgParamValue(
                    device.sku,
                    device.device_id,
                    paramId,
                    paramValue,
                    queries,
                    undefined,
                    logParamRecords,
                );
            }

            /* insert new log value into sqlite table */
            queries.insertLogRecords(device.device_id, logParamRecords);
        }
    };
}

export type NotNullable<T> = {
    [P in keyof T]: null extends T[P] ? Exclude<T[P], null> | undefined : T[P];
};

export function nullToUndefined<T extends object>(v: T): NotNullable<T> {
    const res = v as NotNullable<T>;
    for (const k in v) {
        const val = res[k];
        if (val === null) {
            (res[k] as unknown) = undefined;
        }
    }
    return res;
}

class Queries {
    private statementCache = new Map<string, SqliteStatement>();

    constructor(private db: SqliteDatabase, private memdb: SqliteDatabase) {}

    private getDbStmt(sql: string): SqliteStatement {
        let stmt = this.statementCache.get(sql);
        if (!stmt) {
            stmt = this.db.prepare(sql);
            this.statementCache.set(sql, stmt);
        }
        return stmt;
    }

    private getMemDbStmt(sql: string): SqliteStatement {
        let stmt = this.statementCache.get(sql);
        if (!stmt) {
            stmt = this.memdb.prepare(sql);
            this.statementCache.set(sql, stmt);
        }
        return stmt;
    }

    public selectShelfConfig(
        deviceId: string,
        paramId: string,
    ):
        | {
              item_weight_g: number;
              fixed_tare_weight_g?: number;
              stacked_tare_weight_g?: number;
              stacked_tare_items_max?: number;
          }
        | undefined {
        const stmt = this.getDbStmt(`
            select
                item_weight_g,
                fixed_tare_weight_g,
                stacked_tare_weight_g,
                stacked_tare_items_max
            from lorasens_lwg_shelves_config
            where device_id = @deviceId and weight_g_param_id = @paramId;`);
        return nullToUndefined(
            stmt.get({ deviceId, paramId }) as Record<string, unknown>,
        ) as ReturnType<typeof this.selectShelfConfig>;
    }

    public selectParamLastValue(
        deviceId: string,
        paramId: string,
        timestamp: number,
    ): number | undefined {
        const stmt = this.getDbStmt(`
            select value
            from param_values
            where device_id = @deviceId and
                param_id = @paramId and
                received_on = (
                    select max(received_on)
                    from param_values
                    where device_id = @deviceId and
                        param_id = @paramId and
                        received_on < @timestamp
                );
        `);
        const row = stmt.get({ deviceId, paramId, timestamp }) as
            | {
                  value: number;
              }
            | undefined;
        return row?.value;
    }

    private logParamValue(
        measuredOn: number,
        deviceId: string,
        paramId: string,
        value: string,
    ): void {
        const stmt = this.getDbStmt(`
            insert into param_values (received_on, device_id, param_id, value)
            values (@measuredOn, @deviceId, @paramId, @value);
        `);
        stmt.run({ measuredOn, deviceId, paramId, value });
    }

    private logParamError(
        measuredOn: number,
        deviceId: string,
        paramId: string,
        error: string,
    ): void {
        const stmt = this.getDbStmt(`
            insert into param_values (received_on, device_id, param_id, error)
            values (@measuredOn, @deviceId, @paramId, @error);
        `);
        stmt.run({ measuredOn, deviceId, paramId, error });
    }

    public selectLorasensDevice(
        did: number,
    ): { device_id?: string; sku?: string; firmware_version?: number } | undefined {
        const stmt = this.getDbStmt(`
            select device_id, sku, firmware_version
            from lorasens_devices where did=@did;
        `);
        return nullToUndefined(stmt.get({ did }) as Record<string, unknown>) as ReturnType<
            typeof this.selectLorasensDevice
        >;
    }

    private upsertParamLastResultValue(
        measuredOn: number,
        deviceId: string,
        paramId: string,
        value: string,
    ): void {
        const stmt = this.getMemDbStmt(`
            insert into param_last_results (device_id, param_id, resulted_on, value)
            values (@deviceId, @paramId, @measuredOn, @value)
            on conflict(device_id, param_id)
                do update set resulted_on = @measuredOn, value = @value, error = null;
        `);
        stmt.run({ measuredOn, deviceId, paramId, value });
    }

    private upsertParamLastResultError(
        measuredOn: number,
        deviceId: string,
        paramId: string,
        error: string,
    ): void {
        const stmt = this.getMemDbStmt(`
            insert into param_last_results (device_id, param_id, resulted_on, error)
            values (@deviceId, @paramId, @measuredOn, @error)
            on conflict(device_id, param_id)
                do update set resulted_on = @measuredOn, value = null, error = @error;
        `);
        stmt.run({ measuredOn, deviceId, paramId, error });
    }

    public upsertLastReadings(
        deviceId: string,
        results: Record<string, DeviceParameterResult>,
    ): void {
        // TODO: use bulk upsert
        for (const paramId in results) {
            if (!results[paramId]) {
                continue;
            }
            const error = results[paramId].error;
            const value = results[paramId].value;
            if (error) {
                this.upsertParamLastResultError(
                    results[paramId].timestamp.getTime() / 1000,
                    deviceId,
                    paramId,
                    error,
                );
            }
            if (value) {
                this.upsertParamLastResultValue(
                    results[paramId].timestamp.getTime() / 1000,
                    deviceId,
                    paramId,
                    value,
                );
            }
        }
    }

    public insertLogRecords(
        deviceId: string,
        results: Record<string, DeviceParameterResult>,
    ): void {
        // TODO: use bulk insert
        for (const paramId in results) {
            if (!results[paramId]) {
                continue;
            }
            const error = results[paramId].error;
            const value = results[paramId].value;
            if (error) {
                this.logParamError(
                    results[paramId].timestamp.getTime() / 1000,
                    deviceId,
                    paramId,
                    error,
                );
            }
            if (value) {
                this.logParamValue(
                    results[paramId].timestamp.getTime() / 1000,
                    deviceId,
                    paramId,
                    value,
                );
            }
        }
    }
}

async function run(): Promise<void> {
    console.log("Running...");

    const config = getUserJson(CONFIG_SCHEMA);

    const db = connectMainDb();
    const memdb = connectMemDb();
    const queries = new Queries(db, memdb);

    const busSubscriber = getCmdBusSubscriber();

    console.log("Listening for ls-adv on bus");
    busSubscriber.registerTaskRequestHandler(
        "ls-adv",
        createLsAdvHandler(
            {
                addUnitsToValue: !!config.addUnitsToValue,
                logGeneralData: !!config.logAdvsGeneralData,
                logCustomData: !!config.logAdvsCustomData,
                lwgCalcItemsFromAdvs: !!config.lwgCalcItemsFromAdvs,
            },
            queries,
        ),
    );

    console.log("Listening for ls-log on bus");
    busSubscriber.registerTaskRequestHandler(
        "ls-log",
        createLsLogHandler(!!config.addUnitsToValue, !!config.lwgCalcItemsFromLogs, queries),
    );

    return new Promise(() => {});
}

run();
