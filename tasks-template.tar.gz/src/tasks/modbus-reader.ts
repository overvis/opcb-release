// @opcbTaskName Example Modbus device reading task
// @opcbTaskDescription This task reads a list of registers and stores them in database.

import { ModbusDefinedFunctionCode, ModbusRequest, ModbusResponsePayload } from "@overvis/modbus";
import {
    connectMainDb,
    getModbusInterface,
    getUserJson,
    ModbusInterface,
    setTestWorkerData,
} from "@overvis/opcb-tasks-helpers";
import { MAPPERS, SqliteStatement, timeout } from "@overvis/opcb-ts-shared";
import { Static, Type } from "@sinclair/typebox";

const MAPPER_TYPE_SCHEMA = Type.Union([
    Type.Literal("boolean"),
    Type.Literal("int16"),
    Type.Literal("uint16"),
    Type.Literal("int32-be"),
    Type.Literal("int32-le"),
    Type.Literal("uint32-be"),
    Type.Literal("uint32-le"),
    Type.Literal("float-be"),
    Type.Literal("float-le"),
    Type.Literal("double-word-be"),
    Type.Literal("double-word-le"),
    Type.Literal("utf8str"),
    Type.Literal("bit"),
]);
type MapperType = Static<typeof MAPPER_TYPE_SCHEMA>;

const PARAM_SCHEMA = Type.Object({
    deviceId: Type.String(),
    paramId: Type.String(),
    modbusSlaveId: Type.Integer({ minimum: 0, maximum: 255 }),
    registerType: Type.Union([
        Type.Literal("input"),
        Type.Literal("holding"),
        Type.Literal("coil"),
        Type.Literal("discrete"),
    ]),
    address: Type.Integer({ minimum: 0, maximum: 65535 }),
    quantity: Type.Integer({ minimum: 1, maximum: 125 }),
    type: MAPPER_TYPE_SCHEMA,
    multiplier: Type.Optional(Type.Number()),
    shift: Type.Optional(Type.Number()),
    bitPos: Type.Optional(Type.Integer({ minimum: 0, maximum: 15 })),
});
type Param = Static<typeof PARAM_SCHEMA>;

const CONFIG_SCHEMA = Type.Object({
    readPeriodMsec: Type.Integer(),
    params: Type.Array(PARAM_SCHEMA),
});
type Config = Static<typeof CONFIG_SCHEMA>;

setTestWorkerData({
    taskId: "modbus-reader",
    userJson: JSON.stringify({
        readPeriodMsec: 1000,
        params: [
            {
                deviceId: "device1",
                paramId: "param1",
                modbusSlaveId: 111,
                registerType: "holding",
                address: 0,
                quantity: 1,
                type: "int16",
            },
        ],
    } satisfies Config),
});

type SaveValueStatement = SqliteStatement<{
    receivedOn: number;
    deviceId: string;
    paramId: string;
    value: string;
}>;
type SaveErrorStatement = SqliteStatement<{
    receivedOn: number;
    deviceId: string;
    paramId: string;
    error: string;
}>;

async function run(): Promise<void> {
    console.log("Running...");
    const config = getUserJson(CONFIG_SCHEMA);
    const modbus = getModbusInterface();
    const db = connectMainDb();
    const saveValue: SaveValueStatement = db.prepare(`
        insert into param_values (received_on, device_id, param_id, value)
        values (@receivedOn, @deviceId, @paramId, @value);`);
    const saveError: SaveErrorStatement = db.prepare(`
        insert into param_values (received_on, device_id, param_id, error)
        values (@receivedOn, @deviceId, @paramId, @error);`);

    return new Promise((_resolve, reject) => {
        setInterval(() => {
            try {
                runReadCycle(config, modbus, saveValue, saveError).catch(reject);
            } catch (e) {
                reject(e);
            }
        }, config.readPeriodMsec);
    });
}

async function runReadCycle(
    config: Config,
    modbus: ModbusInterface,
    saveValue: SaveValueStatement,
    saveError: SaveErrorStatement,
): Promise<void> {
    for (const param of config.params) {
        console.log(
            `Reading ${param.paramId} from slave ${param.modbusSlaveId} ` +
                `register ${param.address} len ${param.quantity} type ${param.type}...`,
        );

        try {
            const req = createRequest(param);
            const resp = await timeout(1000, modbus.sendModbusRequest(req));
            if ("error" in resp.payload) {
                throw new Error(`Modbus exception 0x${resp.payload.error.errorCode.toString(16)}`);
            }
            const valueNums = getValues(resp.payload.correct);
            const valueStr = mapValues(
                valueNums,
                param.type,
                param.multiplier,
                param.shift,
                param.bitPos,
            );
            saveValue.run({
                receivedOn: Date.now() / 1000,
                deviceId: param.deviceId,
                paramId: param.paramId,
                value: valueStr,
            });
        } catch (e) {
            console.error(e);
            saveError.run({
                receivedOn: Date.now() / 1000,
                deviceId: param.deviceId,
                paramId: param.paramId,
                error: e instanceof Error ? e.message : (e as object).toString(),
            });
        }
    }
}

function getValues(payload: ModbusResponsePayload): Uint16Array {
    if (!("functionCode" in payload)) {
        throw new Error(
            `Unexpected response function code: ${
                "otherFunctionCode" in payload ? payload.otherFunctionCode : "unknown"
            }`,
        );
    }
    switch (payload.functionCode) {
        case ModbusDefinedFunctionCode.ReadCoils:
        case ModbusDefinedFunctionCode.ReadDiscreteInputs:
            return Uint16Array.from(payload.values.map((x) => (x ? 1 : 0)));
        case ModbusDefinedFunctionCode.ReadInputRegisters:
        case ModbusDefinedFunctionCode.ReadHoldingRegisters:
            return payload.values;
        default:
            throw new Error(`Unexpected response function code: ${payload.functionCode}`);
    }
}

function createRequest(param: Param): Omit<ModbusRequest, "protocol"> {
    let functionCode: ModbusDefinedFunctionCode;
    switch (param.registerType) {
        case "coil":
            functionCode = ModbusDefinedFunctionCode.ReadCoils;
            break;
        case "discrete":
            functionCode = ModbusDefinedFunctionCode.ReadDiscreteInputs;
            break;
        case "input":
            functionCode = ModbusDefinedFunctionCode.ReadInputRegisters;
            break;
        case "holding":
            functionCode = ModbusDefinedFunctionCode.ReadHoldingRegisters;
            break;
    }
    return {
        slaveId: param.modbusSlaveId,
        payload: {
            functionCode,
            address: param.address,
            quantity: param.quantity,
        },
    };
}

function mapValues(
    v: Uint16Array,
    mapperType: MapperType,
    multiplier?: number,
    shift?: number,
    bitPos?: number,
): string {
    if (multiplier === undefined) {
        multiplier = 1;
    }
    if (shift === undefined) {
        shift = 0;
    }
    if (bitPos === undefined) {
        bitPos = 0;
    }
    switch (mapperType) {
        case "boolean":
            return MAPPERS.u16.bool(v[0]) ? "1" : "0";
        case "int16":
            return (MAPPERS.u16.i16(v[0]) * multiplier + shift).toString();
        case "uint16":
            return (MAPPERS.u16.u16(v[0]) * multiplier + shift).toString();
        case "int32-be":
            return (MAPPERS.u16s.i32([v[0], v[1]]) * multiplier + shift).toString();
        case "int32-le":
            return (MAPPERS.u16s.i32([v[1], v[0]]) * multiplier + shift).toString();
        case "uint32-be":
            return (MAPPERS.u16s.u32([v[0], v[1]]) * multiplier + shift).toString();
        case "uint32-le":
            return (MAPPERS.u16s.u32([v[1], v[0]]) * multiplier + shift).toString();
        case "float-be":
            return (MAPPERS.u16s.f32([v[0], v[1]]) * multiplier + shift).toString();
        case "float-le":
            return (MAPPERS.u16s.f32([v[1], v[0]]) * multiplier + shift).toString();
        case "double-word-be":
            return (MAPPERS.u16s.f64([v[0], v[1], v[2], v[3]]) * multiplier + shift).toString();
        case "double-word-le":
            return (MAPPERS.u16s.f64([v[3], v[2], v[1], v[0]]) * multiplier + shift).toString();
        case "utf8str":
            return MAPPERS.u16s.utf8str(Array.from(v));
        case "bit":
            return v[0] & (1 << bitPos) ? "1" : "0";
        default:
            throw new Error(`Unknown mapper type: ${mapperType}`);
    }
}

run();
